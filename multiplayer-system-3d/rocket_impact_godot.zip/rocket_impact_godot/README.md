# Rocket impact for Godot 4

Import `godot/project.godot` and press F6 with `demo.tscn` open, or F5 from anywhere in the project. The demo plays a floor impact on startup. Click the floor or wall to place another impact. Space replays the floor impact, W replays the wall impact, and S toggles slow motion.

## Add it to your game

Copy `godot/effects/rocket_impact/` to `res://effects/rocket_impact/`. Spawn the scene once when your rocket hits, then pass the world-space hit position, the world-space surface normal, and the local up direction. For a spherical planet, local up can be the normalized vector from its center to the hit position.

```gdscript
const ROCKET_IMPACT = preload("res://effects/rocket_impact/rocket_impact.tscn")

func show_rocket_impact(
        hit_position: Vector3,
        hit_normal: Vector3,
        planet_center: Vector3
) -> void:
    var burst := ROCKET_IMPACT.instantiate()
    add_child(burst)
    var local_up := (hit_position - planet_center).normalized()
    burst.play(hit_position, hit_normal, local_up)
```

Set `effect_scale` before calling `play()` to scale the burst's footprint and travel distances. The optional fourth argument is a random seed. Set `auto_free` to false before calling `play()` if you'd like to keep the scene for replay. The scene emits `finished` after the last particle expires.

The effect uses two instanced batches and procedural shaders in Godot's Compatibility renderer. It has no texture dependencies. Particle bounce uses a plane tangent to the impact surface. The implementation uses original silhouettes, tuned Godot-space sizes and motion, and a short sequence of puffs for the dust ribbons.

Headless checks in Godot 4.7 covered floor and wall impacts, radial up, particle motion, both dust branches, replay, and cleanup. The floor and wall effects were also checked in Godot’s graphical preview. Web export remains unverified.

## Source reference

`reference/` contains the extracted Source particle graph and materials for `ExplosionCore_Wall`, the normal rocket impact against a surface. The Godot scene runs independently of these files.

- `rocket_explosion.emitters.json` lists the systems by name with inline operators and child edges.
- `rocket_explosion.particles.json` preserves typed attributes, original element IDs, UUIDs, and array order.
- `rocket_explosion.materials.json` maps systems to materials and includes atlas frame rectangles, sequence IDs, and checksums for the packaged files.
- `source/` holds the scoped binary PCF and the 12 referenced VMT/VTF pairs present in the supplied mod. The two unresolved base-game materials are `effects/softglow.vmt` and `effects/debris/debris_chunk.vmt`.

The root renders no particles itself. It has 12 direct child entries, including two distinct links to `Explosion_Dustup`. There are 14 unique descendant emitter definitions. Each dust branch has its own `Explosion_Dustup_2` trail. The flash and spikes last about 0.13–0.18 s. The earliest smoke uses 10 atlas frames at 20 fps, the flame uses 15 at 32 fps, and the secondary smoke lasts 0.9–1.6 s per particle.

Source package `toon_explosions_v1.1.vpk`, entry `particles/bigboom.pcf`. The ZIP includes a scoped PCF with remapped reference indices. The referenced VMT and VTF files are byte-for-byte extractions. See [Toon Explosion FX v1.1](https://gamebanana.com/mods/12446) and the [stock rocket launcher effect mapping](https://www.teamfortress.tv/35367/vtf-crosshair-pack).

| Input | SHA-256 |
|---|---|
| VPK | `9753f4a12dc8a120bafff427a96b92cf7858163c08bf782d80ef287e92dd1557` |
| Original PCF | `5a583e7509e1f952635ce09d58d074be99953b08c0f9faff3723ef995aadeaa9` |
