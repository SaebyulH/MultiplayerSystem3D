# Toon Explosion FX collection for Godot

Open `godot/project.godot` in Godot 4.6 or newer and press F5. The effect picker has 31 additional presets from the two mod packages, plus the rocket surface impact from the earlier export.

- Use the effect picker and **Replay** or **Space**. Click a point on the demo floor or wall to place the effect there.
- Press **W** to preview against the wall and **S** to toggle slow motion.
- The package name in the picker distinguishes effects whose identifiers appear in both particle files. Long smoke systems can take up to about 27 seconds at normal speed.

## Use a preset in your game

Copy `godot/effects/` into the project's `res://effects/` directory. The general explosion scene uses the procedural shaders in the rocket impact folder.

```gdscript
const TOON_EXPLOSION = preload("res://effects/toon_explosions/toon_explosion.tscn")

func play_hoodoo(hit_position: Vector3, hit_normal: Vector3, local_up: Vector3) -> void:
    var effect := TOON_EXPLOSION.instantiate()
    effect.effect_scale = 0.75
    add_child(effect)
    effect.play("dirty_explode/asplode_hoodoo", hit_position, hit_normal, local_up)
```

See `catalog.json` for stable preset IDs. Call `play()` after adding the node to the tree. It returns false for an unknown ID. An optional fifth argument supplies a random seed. The scene emits `finished` and frees itself by default. Set `auto_free` to false for reuse between bursts. For a game export, include `effects/toon_explosions/profiles.json` in the preset's non-resource include filter. [Godot export documentation](https://docs.godotengine.org/en/stable/tutorials/export/exporting_projects.html)

The 31 previews use each source effect's emitter graph, child delays, lifetimes, colors, and size and fade curves. The 3D motion, collisions, trails, and materials are approximated with Godot geometry and original shaders. Dense emitters have sample caps and open-ended emission runs for 2.5 seconds so a preview can finish. The scenes are visual effects.

## Source files

| Input particle file | Additional presets |
|---|---:|
| `bigboom.pcf` | 17 |
| `dirty_explode.pcf` | 14 |

Each effect under `reference/<particle file>/effects/<effect>/` has its own scoped binary PCF, typed `particles.json`, and flattened `emitters.json`. These preserve source values, operator order, and duplicate child links. The binary files remap element indices to the scoped graph.

Each particle file has a shared `materials.json` manifest for its presets. It links the original VMT and VTF bytes under `source/materials/`, with checksums and embedded atlas rectangles where available. Entries marked `in_mod: false` reference base-game materials outside the supplied package. The original rocket extraction is included under `reference/rocket_surface_impact/`.

I round-tripped all 31 scoped PCFs and exercised every Godot preset headlessly in Godot 4.6.3. I also checked the underwater surface impact and both payload explosions in the graphical preview.
