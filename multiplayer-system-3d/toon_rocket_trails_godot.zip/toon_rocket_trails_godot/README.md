# Toon Rocket Trails for Godot

Open `godot/project.godot` in Godot 4.6 or newer and press F5. The demo runs a projectile along a curved path and then lets the trail fade. Use the picker to select a trail, **Space** to replay, and **S** for slow motion.

The 29 presets include standard, underwater, Air Strike, sentry, critical, and Pyrovision rockets, plus red and blue flare and Scorch Shot variants. The Air Strike and critical overlays can also be previewed separately. The standard rocket uses connected, camera-facing strips with a bright core and layered smoke. Flare and Scorch Shot profiles add team-colored exhaust and, where configured, rings or a spiraling ribbon.

## Attach a trail to a projectile

Copy `godot/effects/toon_trail/` into your project at `res://effects/toon_trail/`. Add a `Marker3D` to your projectile at the exhaust position and orient its local **−Z** toward the nose. Add the trail scene to a world or effects node so it can outlive the projectile.

```gdscript
const TOON_TRAIL = preload("res://effects/toon_trail/toon_trail.tscn")

func launch_trail(nozzle: Node3D) -> Node3D:
    var trail := TOON_TRAIL.instantiate()
    trail.effect_scale = 1.0
    add_child(trail)
    trail.start("rockettrail", nozzle)
    return trail
```

`catalog.json` lists the supported IDs. `start()` returns false for an unknown ID or an invalid nozzle. The optional third argument sets a random seed. Call `stop()` at impact. Freeing the exhaust marker also stops emission. Previously emitted samples drain in world space and the trail emits `finished`, then frees itself by default. Set `auto_free` to false to restart the same node with `start()`.

## Extracted reference

- `reference/rockettrail/` contains typed particle and flattened emitter JSON for all 85 definitions. This includes incidental stock tracer and healing definitions. The Godot picker focuses on the rocket and flare effects.
- `reference/halloween/` contains the five Air Strike definitions from `halloween.pcf`. Their scoped binary is under `reference/source/particles/`.
- `reference/source/particles/` also contains byte-identical copies of the mod's `rockettrail.pcf` and `rockettrail_dx80.pcf`.
- `reference/materials.json` lists the material dependencies, with hashes and atlas frame coordinates for supplied textures. `in_mod: false` marks references supplied by the base game or absent from the archive.

The Godot presets use original procedural shading, with source-derived rates, colors, lifetimes, and width curves. The port caps emission and tessellation density and approximates specialized Source operators. The Godot demo and its graphics run independently of the Source reference files.

All 29 presets were exercised headlessly in Godot 4.7. The checks covered moving-nozzle emission, connected ribbon geometry, and cleanup after stop or nozzle removal. Graphical and web previews were unverified in this session.

Source reference by Chaofanatic. [Toon Rocket Trails on GameBanana](https://gamebanana.com/mods/12410)
